export default {
    prizes: [
        { fonts: [{ text: "丘大叔", top: "10%" }], background: "#e9e8fe" ,show:'true'},
        { fonts: [{ text: "茶理一世", top: "10%" }], background: "#b8c5f2" ,show:'true'},
        { fonts: [{ text: "一点点", top: "10%" }], background: "#e9e8fe" ,show:'true'},
        { fonts: [{ text: "茶百道", top: "10%" }], background: "#b8c5f2" ,show:'true'},
        { fonts: [{ text: "森林子", top: "10%" }], background: "#e9e8fe" ,show:'true'},
        { fonts: [{ text: "LINLEE", top: "10%" }], background: "#b8c5f2" ,show:'true'},
    ],
}